ARIANNA RIVA — VERSIONE 3

Questa è una base tecnica locale. La chiave API NON va inserita nei file HTML.

Requisiti:
- Python 3.10+
- una API key OpenAI

Avvio:
1. Imposta la variabile d'ambiente OPENAI_API_KEY.
2. Apri un terminale nella cartella.
3. Esegui: python server.py
4. Apri arianna_chat.html nel browser.

Nota:
- Il prototipo usa un backend locale.
- La memoria iniziale è in memory.json.
- Prima di pubblicarlo online vanno aggiunti autenticazione, database,
  protezione CORS, rate limiting, logging sicuro e gestione degli errori.
- L'integrazione con OnlyFans va fatta solo tramite modalità ufficialmente
  consentite dalla piattaforma; questo pacchetto non effettua scraping o
  automazioni non autorizzate.
