import json, os
from pathlib import Path
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
from urllib.request import Request, urlopen

ROOT = Path(__file__).parent
SYSTEM = (ROOT / "arianna_personality.txt").read_text(encoding="utf-8")
MEMORY_FILE = ROOT / "memory.json"

def load_memory():
    return json.loads(MEMORY_FILE.read_text(encoding="utf-8"))

def save_memory(data):
    MEMORY_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

class Handler(BaseHTTPRequestHandler):
    def _json(self, code, payload):
        raw = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        if urlparse(self.path).path != "/chat":
            return self._json(404, {"error": "Not found"})
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length) or b"{}")
        fan = body.get("fan", "guest")
        message = body.get("message", "").strip()
        if not message:
            return self._json(400, {"error": "Empty message"})

        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            return self._json(503, {
                "error": "OPENAI_API_KEY non configurata",
                "message": "Configura la chiave API come variabile d'ambiente sul tuo computer."
            })

        memory = load_memory().get(fan, {})
        user_prompt = (
            f"Profilo fan: {json.dumps(memory, ensure_ascii=False)}\n"
            f"Messaggio del fan: {message}\n"
            "Rispondi come Arianna. Mantieni la risposta naturale e concisa."
        )

        payload = json.dumps({
            "model": "gpt-5.6",
            "input": [
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": user_prompt}
            ]
        }).encode()

        req = Request(
            "https://api.openai.com/v1/responses",
            data=payload,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            },
            method="POST"
        )

        try:
            with urlopen(req, timeout=60) as r:
                result = json.loads(r.read().decode())
            text = result.get("output_text", "")
            if not text:
                return self._json(502, {"error": "Nessun testo ricevuto dal modello"})
            return self._json(200, {"reply": text, "fan": fan})
        except Exception as e:
            return self._json(502, {"error": "Errore chiamata API", "detail": str(e)})

if __name__ == "__main__":
    print("Arianna backend: http://127.0.0.1:8000")
    HTTPServer(("127.0.0.1", 8000), Handler).serve_forever()
